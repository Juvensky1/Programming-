#1: It was a lot easier to write the remaining code.
#2: We could add two racer objects or sort a list of racer objects.